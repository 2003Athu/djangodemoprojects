from django.contrib import admin

from movie.models import Movie

admin.site.register(Movie)